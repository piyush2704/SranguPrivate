import { TestBed, async , fakeAsync , tick } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { AppComponent } from "./app.component";
import { OrderSummaryComponent } from "./order-summary/order-summary.component";
import { CreateOrderComponent } from "./create-order/create-order.component";
import { ProductListingPageComponent } from "./product-listing-page/product-listing-page.component";
import { ProductService} from './product.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable, Observer } from 'rxjs';

describe("AppComponent", () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule,HttpClientTestingModule,ReactiveFormsModule,FormsModule],
      declarations: [AppComponent,
        OrderSummaryComponent,
        CreateOrderComponent,
        ProductListingPageComponent],
    }).compileComponents();
  }));

  function setup() {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    const productService = fixture.debugElement.injector.get(ProductService);
    return { fixture, app , productService };
  }

  it('should create the app', async(() => {
    const { app } = setup();
    expect(app).toBeTruthy();
  }));

  it('should render title in a h1 tag', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Bloom & Wild');
  }));

});
