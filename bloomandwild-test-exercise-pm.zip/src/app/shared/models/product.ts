export class Product {
 
    public name: string;
    public id: number;
    public price_pennies: number;
    public currency: string;
    public images:string;
    public product_count: number;
   
    constructor(name:string, id:number, price_pennies:number , currency: string , images : string , product_count: number ) {
      this.id = id;
      this.name = name;
      this.currency = currency;
      this.price_pennies = price_pennies;
      this.images = images;
      this.product_count = 1;
      
    }
     
  }