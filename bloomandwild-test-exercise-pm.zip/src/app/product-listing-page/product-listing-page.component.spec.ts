import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { ProductListingPageComponent } from './product-listing-page.component';
import { ProductService} from '../product.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable, Observer } from 'rxjs';

describe('ProductListingPageComponent', () => {
  let component: ProductListingPageComponent;
  let fixture: ComponentFixture<ProductListingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,ReactiveFormsModule,FormsModule],
      declarations: [ ProductListingPageComponent ]
    })
    .compileComponents();
  }));
  
  function setup() {
    const fixture = TestBed.createComponent(ProductListingPageComponent);
    const app = fixture.debugElement.componentInstance;
    const productService = fixture.debugElement.injector.get(ProductService);
    return { fixture, app , productService };
  }


  it('should create the app', async(() => {
    const { app } = setup();
    expect(app).toBeTruthy();
  }));


  it('should have h1 tag as \'Products\'', async(() => {
    const { app, fixture } = setup();
    fixture.detectChanges();
    const compile = fixture.debugElement.nativeElement;
    const h3tag = compile.querySelector('h3');
    expect(h3tag.textContent).toBe('Products');
  }));
  
});
