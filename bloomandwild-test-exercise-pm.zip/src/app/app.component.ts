import { Component, OnInit } from "@angular/core";
import { ProductService } from './product.service';
import { Product } from './shared/models/product'

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit {

  constructor(private productService: ProductService) { }
  basket: any = new Array<Product>();
  subTotal: number = 0;
  totalDiscunt: number = 0;

  orderSummary: any = [];


  pushToBasket(item) {
    this.productService.getProductDetails(item.id).subscribe(response => {
      if (this.basket.length) {
        if (this.basket.find(data => { return data.id == response.id })) {
          this.basket.filter(item => {
            if (item.id == response.id) {
              item.product_count++;
            }
          })
        } else {
          this.basket.push(
            new Product(
              response.name,
              response.id,
              response.price_pennies,
              response.currency,
              response.images,
              response.product_count
            ))
        }
      } else {
        this.basket.push(
          new Product(
            response.name,
            response.id,
            response.price_pennies,
            response.currency,
            response.images,
            response.product_count
          ))
      }
      this.totalDiscunt = this.calculatedSum(this.basket, 'product_count') - 1;
      this.subTotal = this.calculatedSum(this.basket, 'price_pennies', 'product_count');
    })


  }

  calculatedSum(data, key, key_modifier?) {
    return key_modifier ? data.reduce((a, b) => a + ((b[key] || 0) * (b[key_modifier] || 0)), 0)
      : data.reduce((a, b) => a + (b[key] || 0), 0);
  }

  createOrder(emailAddress) {
    let productData = new Array<Object>()
    productData = this.basket.map(data => {
      return ({ 'id': data.id, 'quantity': data.product_count })
    });

    let req = {
      'email': emailAddress,
      'products': productData,
    }

    this.productService.creatNewOrder(req).subscribe(data => {
      alert('Order Successfully Created')
    })
  }
  deleteRow(id) {
    let index = this.basket.findIndex(d => d.id === id); //find index in your array
    this.basket.splice(index, 1);
    this.totalDiscunt = this.calculatedSum(this.basket, 'product_count') - 1;
    this.subTotal = this.calculatedSum(this.basket, 'price_pennies', 'product_count');

  }

  ngOnInit() {
  }
}
