import { Component, OnInit, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-create-order',
  templateUrl: './create-order.component.html',
  styleUrls: ['./create-order.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CreateOrderComponent implements OnInit {
  @Input() basket: any;
  @Output() createOrder = new EventEmitter()
  order = new FormGroup({
    emailAddress: new FormControl(null, [Validators.required, Validators.email, this.emailValidator]),
  });
  formSubmitted: Boolean = false;
  get emailAddress() {
    return this.order.get('emailAddress');
  }
  constructor() { }

  ngOnInit() {
  }
  submitForm() {
    this.formSubmitted = true;
    if (this.order.valid) {
      this.createOrder.emit(this.order.value.emailAddress)
    }
  }
  emailValidator(control: AbstractControl): { [key: string]: boolean } | null {
    if (!(/@bloomandwild.com\s*$/.test(control.value)) && !(/@bloomandwild.de\s*$/.test(control.value))
      && !(/@bloomandwild.fr\s*$/.test(control.value))) {
      return { 'emailError': true };
    }
    return null;
  }
}
