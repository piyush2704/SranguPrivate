import { Component, OnInit,ViewEncapsulation , Input, Output, EventEmitter} from '@angular/core';
import {ProductService} from '../product.service';

@Component({
  selector: 'app-order-summary',
  templateUrl: './order-summary.component.html',
  styleUrls: ['./order-summary.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class OrderSummaryComponent implements OnInit {

  @Input() basket: any;
  @Input() subTotal: any;
  @Input() totalDiscunt: any;
  @Output() deleteRow = new EventEmitter();

  constructor(private productService: ProductService) { }

  ngOnInit() {
  }

}
