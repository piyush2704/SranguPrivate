import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { CreateOrderComponent } from './create-order.component';
import { ProductListingPageComponent } from '../product-listing-page/product-listing-page.component'
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('CreateOrderComponent', () => {
  let component: CreateOrderComponent;
  let fixture: ComponentFixture<CreateOrderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateOrderComponent ],
      imports: [HttpClientModule,ReactiveFormsModule,FormsModule], 
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

 /*  it('should call submitForm function', async(() => {
    spyOn(component, 'submitForm');
    fixture.detectChanges();
    let compiled = fixture.debugElement.nativeElement;
    compiled.querySelector('button').click();
    fixture.detectChanges();
    expect(component.submitForm).toHaveBeenCalled();
  })); */
});
