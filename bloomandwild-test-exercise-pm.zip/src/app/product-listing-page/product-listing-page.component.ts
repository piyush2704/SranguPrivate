import { Component, OnInit, ViewEncapsulation, Output, EventEmitter } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../shared/models/product'

export interface ProductList {

}

@Component({
  selector: 'app-product-listing-page',
  templateUrl: './product-listing-page.component.html',
  styleUrls: ['./product-listing-page.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductListingPageComponent implements OnInit {

  products: any = new Array<Product>();
  @Output() pushToBasket: any = new EventEmitter();

  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.productService.getProductList().subscribe(response => {
      for (let product of response) {
        this.productService.getProductDetails(product.id).subscribe(data => {
          this.products.push(
            new Product(
              data.name,
              data.id,
              data.price_pennies,
              data.currency,
              data.images,
              data.product_count
            ))
        })
      }
    })
  }

  addToBasket(item: number): void {
    this.pushToBasket.emit(item);
  }
}
