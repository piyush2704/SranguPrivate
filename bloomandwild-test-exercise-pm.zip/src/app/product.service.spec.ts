import { TestBed } from '@angular/core/testing';

import { ProductService } from './product.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('ProductService', () => {
  let httpMock: HttpTestingController;
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
  }));

  it('should be created', () => {
    const service: ProductService = TestBed.get(ProductService);
    expect(service).toBeTruthy();
  });
  it('should call getProductList', () => {
    let  data = 1
    const service: ProductService = TestBed.get(ProductService);
		  service.getProductDetails(data).subscribe((response: any) => {
			expect(response).toBeTruthy();
    });
  });
});
